import { useEffect, useRef, useState } from "react";
import { PRESETS, type Preset } from "@/lib/cad/scripts";
import { runGenerate } from "@/lib/cad/run-generate";
import {
  MODE_LIST,
  SECTION_TITLES,
  TOOL_LIST,
  commitCode,
  clearSession,
  downloadScript,
  issue,
  resetModel,
  toggleFullscreen,
  useStudio,
  type SectionId,
  type StudioMode,
} from "@/lib/cad/store";
import { Viewport } from "@/components/studio/Viewport";

function go(section: SectionId) {
  useStudio.setState({ section });
}

function selectMode(mode: StudioMode) {
  useStudio.setState({ mode });
  if (mode === "vertex") issue({ kind: "vertex" });
}

export function Dashboard({ onLeave }: { onLeave: () => void }) {
  const section = useStudio((s) => s.section);
  const collapsed = useStudio((s) => s.sidebarCollapsed);
  const title = SECTION_TITLES.find((item) => item.id === section)?.title ?? "typeless prompt";
  const bodyRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bodyRef.current?.scrollTo({ top: 0 });
  }, [section]);

  return (
    <div className="dashboard-view active">
      <aside className={collapsed ? "sidebar collapsed" : "sidebar"} id="sidebar">
        <div className="sidebar-top">
          <div className="sidebar-brand">Typeless</div>
          <button
            type="button"
            className="collapse-btn"
            title="Toggle Menu"
            onClick={() => useStudio.setState({ sidebarCollapsed: !collapsed })}
          >
            {"<>"}
          </button>
        </div>
        <ul className="sidebar-menu">
          {SECTION_TITLES.map((item) => (
            <li key={item.id}>
              <button
                type="button"
                className={section === item.id ? "sidebar-item active" : "sidebar-item"}
                onClick={() => go(item.id)}
              >
                <span>{item.title}</span>
              </button>
            </li>
          ))}
        </ul>
      </aside>

      <div className="dashboard-main">
        <div className="dash-header">
          <div className="logo-tag">
            <span className="sparkle">+</span>// {title.toUpperCase()} //
          </div>
          <button type="button" className="back-btn" onClick={onLeave}>
            {"<<"} Return
          </button>
        </div>

        <div
          ref={bodyRef}
          className={section === "settings" ? "dash-body is-settings" : "dash-body"}
        >
          {section === "prompt" || section === "skilled" || section === "settings" ? (
            <div className="section-pane">
              {section === "prompt" ? <StatGrid /> : null}
              {section === "skilled" ? <PresetGrid /> : null}
              {section === "settings" ? <SettingsPanel /> : null}
            </div>
          ) : null}
          <section
            className={section === "settings" ? "studio parked" : "studio"}
            aria-label="Modeling workspace"
            inert={section === "settings" ? true : undefined}
          >
            <StudioNav />
            <ModeBar />
            <ModeExtras />
            <div className="workspace">
              <Viewport />
              {section === "prompt" || section === "blocks" || section === "cad" ? (
                <div className="rail">
                  {section === "prompt" ? <PromptSidebar /> : null}
                  {section === "prompt" || section === "blocks" ? <ToolsSidebar /> : null}
                  {section === "cad" ? <CadSidebar /> : null}
                </div>
              ) : null}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}

function StatGrid() {
  const faces = useStudio((s) => s.faceCount);
  const lastMs = useStudio((s) => s.lastMs);
  const generating = useStudio((s) => s.generating);
  const error = useStudio((s) => s.error);
  const throughput = generating ? "…" : error ? "ERR" : "100%";

  return (
    <div className="dash-grid stats-grid" id="dashGrid">
      <div className="dash-card">
        <div className="dash-card-title">Active Nodes</div>
        <div className="dash-card-value">{faces.toLocaleString()}</div>
      </div>
      <div className="dash-card">
        <div className="dash-card-title">Latency</div>
        <div className="dash-card-value">{lastMs == null ? "—" : `${lastMs}ms`}</div>
      </div>
      <div className="dash-card">
        <div className="dash-card-title">Throughput</div>
        <div className="dash-card-value">{throughput}</div>
      </div>
    </div>
  );
}

function StudioNav() {
  const [open, setOpen] = useState<"file" | "interface" | null>(null);
  const showGrid = useStudio((s) => s.showGrid);
  const showGizmo = useStudio((s) => s.showGizmo);
  const autoRotate = useStudio((s) => s.autoRotate);

  useEffect(() => {
    if (!open) return;
    const close = () => setOpen(null);
    window.addEventListener("pointerdown", close);
    return () => window.removeEventListener("pointerdown", close);
  }, [open]);

  return (
    <header className="topnav">
      <div className="nav-left">
        <div className={open === "file" ? "nav-slot open" : "nav-slot"}>
          <button
            type="button"
            className="nav-item"
            onPointerDown={(event) => event.stopPropagation()}
            onClick={() => setOpen(open === "file" ? null : "file")}
          >
            File <span className="nav-caret">▼</span>
          </button>
          {open === "file" ? (
            <div className="nav-menu" onPointerDown={(event) => event.stopPropagation()}>
              <button
                type="button"
                onClick={() => {
                  resetModel();
                  setOpen(null);
                }}
              >
                New model
              </button>
              <button
                type="button"
                onClick={() => {
                  downloadScript();
                  setOpen(null);
                }}
              >
                Export script
              </button>
              <button
                type="button"
                onClick={() => {
                  issue({ kind: "screenshot" });
                  setOpen(null);
                }}
              >
                Save screenshot
              </button>
            </div>
          ) : null}
        </div>
        <div className={open === "interface" ? "nav-slot open" : "nav-slot"}>
          <button
            type="button"
            className="nav-item"
            onPointerDown={(event) => event.stopPropagation()}
            onClick={() => setOpen(open === "interface" ? null : "interface")}
          >
            Interface <span className="nav-caret">▼</span>
          </button>
          {open === "interface" ? (
            <div className="nav-menu" onPointerDown={(event) => event.stopPropagation()}>
              <button type="button" onClick={() => useStudio.setState({ showGrid: !showGrid })}>
                {showGrid ? "Hide grid" : "Show grid"}
              </button>
              <button type="button" onClick={() => useStudio.setState({ showGizmo: !showGizmo })}>
                {showGizmo ? "Hide gizmo" : "Show gizmo"}
              </button>
              <button type="button" onClick={() => useStudio.setState({ autoRotate: !autoRotate })}>
                {autoRotate ? "Stop orbit" : "Auto orbit"}
              </button>
              <button
                type="button"
                onClick={() => {
                  issue({ kind: "reset-camera" });
                  setOpen(null);
                }}
              >
                Reset camera
              </button>
            </div>
          ) : null}
        </div>
        <button type="button" className="nav-item" onClick={() => go("settings")}>
          Settings
        </button>
      </div>
      <div className="nav-right">
        <div className="nav-item brand-mark">◇ AI CNC</div>
      </div>
    </header>
  );
}

function ModeBar() {
  const mode = useStudio((s) => s.mode);
  const section = useStudio((s) => s.section);

  return (
    <nav className="modebar" aria-label="Modeling modes">
      <button
        type="button"
        className={section === "skilled" ? "mode-btn library active" : "mode-btn library"}
        onClick={() => go("skilled")}
      >
        +M Library
      </button>
      <button
        type="button"
        className={section === "blocks" ? "mode-btn active" : "mode-btn"}
        onClick={() => go("blocks")}
      >
        Tools
      </button>
      <div className="modebar-divider" />
      {MODE_LIST.slice(0, 5).map((item) => (
        <button
          key={item.id}
          type="button"
          className={mode === item.id ? "mode-btn active" : "mode-btn"}
          onClick={() => selectMode(item.id)}
        >
          {item.label}
        </button>
      ))}
      <div className="modebar-divider" />
      {MODE_LIST.slice(5).map((item) => (
        <button
          key={item.id}
          type="button"
          className={mode === item.id ? "mode-btn active" : "mode-btn"}
          onClick={() => selectMode(item.id)}
        >
          {item.label}
        </button>
      ))}
    </nav>
  );
}

function ModeExtras() {
  const mode = useStudio((s) => s.mode);
  const roughness = useStudio((s) => s.roughness);
  const metalness = useStudio((s) => s.metalness);
  const keyLight = useStudio((s) => s.keyLight);
  const tint = useStudio((s) => s.tint);

  if (mode === "material") {
    return (
      <div className="mode-extra">
        <label>
          Roughness
          <input
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={roughness}
            onChange={(event) => useStudio.setState({ roughness: Number(event.target.value) })}
          />
        </label>
        <label>
          Metal
          <input
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={metalness}
            onChange={(event) => useStudio.setState({ metalness: Number(event.target.value) })}
          />
        </label>
      </div>
    );
  }

  if (mode === "lighting") {
    return (
      <div className="mode-extra">
        <label>
          Key light
          <input
            type="range"
            min={0}
            max={3}
            step={0.05}
            value={keyLight}
            onChange={(event) => useStudio.setState({ keyLight: Number(event.target.value) })}
          />
        </label>
      </div>
    );
  }

  if (mode === "texture") {
    return (
      <div className="mode-extra">
        <label>
          Tint
          <input
            className="color-input"
            type="color"
            value={tint}
            onChange={(event) => useStudio.setState({ tint: event.target.value })}
          />
        </label>
      </div>
    );
  }

  return null;
}

function PromptSidebar() {
  const prompt = useStudio((s) => s.prompt);
  const tier = useStudio((s) => s.modelTier);
  const generating = useStudio((s) => s.generating);
  const status = useStudio((s) => s.status);
  const [matches, setMatches] = useState<Preset[]>([]);

  function onPrompt(value: string) {
    useStudio.setState({ prompt: value });
    const query = value.toLowerCase().trim();
    if (!query) {
      setMatches([]);
      return;
    }
    setMatches(
      PRESETS.filter(
        (preset) =>
          preset.text.toLowerCase().includes(query) && preset.text.toLowerCase() !== query,
      ),
    );
  }

  return (
    <aside className="tool-sidebar">
      <div className="sidebar-section">
        <div className="sidebar-title">AI Prompt Generator</div>
        <div className="ai-prompt-box">
          <label className="sr-only" htmlFor="ai-model-select">
            Model
          </label>
          <select
            id="ai-model-select"
            className="ai-select"
            value={tier}
            onChange={(event) =>
              useStudio.setState({
                modelTier: event.target.value === "advanced" ? "advanced" : "fast",
              })
            }
          >
            <option value="fast">Grok 4.5 (Fast)</option>
            <option value="advanced">Grok 4.5 (Advanced)</option>
          </select>
          <label className="sr-only" htmlFor="ai-prompt-input">
            Prompt
          </label>
          <textarea
            className="ai-textarea"
            id="ai-prompt-input"
            autoComplete="off"
            spellCheck={false}
            maxLength={2000}
            placeholder="Describe CNC part modification (e.g., add radial cooling fins, spiraling staircase)..."
            value={prompt}
            onChange={(event) => onPrompt(event.target.value)}
          />
          {matches.length > 0 ? (
            <div className="ai-suggestions" id="ai-suggestions">
              {matches.map((preset) => (
                <button
                  key={preset.tag}
                  type="button"
                  className="ai-suggestion-item"
                  onClick={() => {
                    useStudio.setState({ prompt: preset.text });
                    setMatches([]);
                  }}
                >
                  <span>{preset.text}</span>
                  <span className="tag">{preset.tag}</span>
                </button>
              ))}
            </div>
          ) : null}
          <button
            type="button"
            className="ai-btn"
            id="ai-generate-btn"
            disabled={generating || prompt.trim().length === 0}
            onClick={() => void runGenerate()}
          >
            <span>{generating ? "" : "⚡"}</span>
            <span className={generating ? "spinner" : "sr-only"}>⚙</span>
            <span>{generating ? "Processing..." : "Generate Toolpath"}</span>
          </button>
          {status ? <div className="status-line">{status}</div> : null}
        </div>
      </div>
    </aside>
  );
}

function CadSidebar() {
  const showGrid = useStudio((s) => s.showGrid);
  const showGizmo = useStudio((s) => s.showGizmo);
  const autoRotate = useStudio((s) => s.autoRotate);
  const faces = useStudio((s) => s.faceCount);
  const keyLight = useStudio((s) => s.keyLight);

  return (
    <aside className="tool-sidebar">
      <div className="sidebar-section">
        <div className="sidebar-title">CAD View</div>
        <div className="prop-row">
          <span className="prop-label">Faces</span>
          <span style={{ fontWeight: 500 }}>{faces.toLocaleString()}</span>
        </div>
        <p className="status-line" style={{ marginTop: 8 }}>
          Drag to orbit. Scroll or pinch to zoom.
        </p>
      </div>
      <div className="sidebar-section">
        <div className="sidebar-title">Image</div>
        <div className="settings-actions">
          <button type="button" className="ai-btn" onClick={() => issue({ kind: "screenshot" })}>
            Save image
          </button>
          <button type="button" className="ai-btn" onClick={() => issue({ kind: "reset-camera" })}>
            Reset camera
          </button>
        </div>
      </div>
      <div className="sidebar-section">
        <div className="sidebar-title">Display</div>
        <label className="prop-row">
          <span className="prop-label">Grid</span>
          <input
            type="checkbox"
            checked={showGrid}
            onChange={(event) => useStudio.setState({ showGrid: event.target.checked })}
          />
        </label>
        <label className="prop-row">
          <span className="prop-label">Gizmo</span>
          <input
            type="checkbox"
            checked={showGizmo}
            onChange={(event) => useStudio.setState({ showGizmo: event.target.checked })}
          />
        </label>
        <label className="prop-row">
          <span className="prop-label">Auto orbit</span>
          <input
            type="checkbox"
            checked={autoRotate}
            onChange={(event) => useStudio.setState({ autoRotate: event.target.checked })}
          />
        </label>
        <div className="prop-row" style={{ marginTop: 10 }}>
          <span className="prop-label">Key light</span>
        </div>
        <input
          type="range"
          min={0}
          max={3}
          step={0.05}
          value={keyLight}
          aria-label="Key light"
          onChange={(event) => useStudio.setState({ keyLight: Number(event.target.value) })}
        />
      </div>
    </aside>
  );
}

function ToolsSidebar() {
  const activeTool = useStudio((s) => s.activeTool);
  const ratio = useStudio((s) => s.ratio);
  const faces = useStudio((s) => s.faceCount);
  const position = useStudio((s) => s.position);

  return (
    <aside className="tool-sidebar">
      <div className="sidebar-section">
        <div className="sidebar-title">Active Tools</div>
        <div className="tool-grid" id="tool-grid">
          {TOOL_LIST.map((tool) => (
            <button
              key={tool.id}
              type="button"
              className={activeTool === tool.id ? "tool-icon active" : "tool-icon"}
              title={tool.title}
              onClick={() => {
                useStudio.setState({ activeTool: tool.id });
                issue({ kind: "tool", tool: tool.id });
              }}
            >
              {tool.label}
            </button>
          ))}
        </div>
      </div>

      <div className="sidebar-section">
        <div className="sidebar-title">Decimate Modifier</div>
        <div className="prop-row">
          <span className="prop-label">Ratio</span>
          <input
            type="text"
            className="prop-value"
            aria-label="Decimate ratio"
            value={ratio.toFixed(2)}
            onChange={(event) => {
              const next = Number(event.target.value);
              if (!Number.isFinite(next)) return;
              const clamped = Math.min(2, Math.max(0.05, next));
              useStudio.setState({ ratio: clamped });
              issue({ kind: "scale", ratio: clamped });
            }}
          />
        </div>
        <input
          type="range"
          min={0.05}
          max={1}
          step={0.05}
          value={Math.min(1, ratio)}
          aria-label="Decimate ratio slider"
          onChange={(event) => {
            const next = Number(event.target.value);
            useStudio.setState({ ratio: next });
            issue({ kind: "scale", ratio: next });
          }}
        />
        <div className="prop-row" style={{ marginTop: 10 }}>
          <span className="prop-label">Faces</span>
          <span style={{ fontWeight: 500 }}>{faces.toLocaleString()}</span>
        </div>
      </div>

      <div className="sidebar-section">
        <div className="sidebar-title">Transform</div>
        {(["x", "y", "z"] as const).map((axis) => (
          <div className="prop-row" key={axis} style={axis === "x" ? undefined : { marginTop: 6 }}>
            <span className="prop-label">Position {axis.toUpperCase()}</span>
            <input
              type="text"
              className="prop-value"
              aria-label={`Position ${axis.toUpperCase()}`}
              value={`${position[axis].toFixed(2)} m`}
              onChange={(event) => {
                const next = Number.parseFloat(event.target.value);
                if (!Number.isFinite(next)) return;
                const positionNext = { ...useStudio.getState().position, [axis]: next };
                useStudio.setState({ position: positionNext });
                issue({ kind: "position", ...positionNext });
              }}
            />
          </div>
        ))}
      </div>
    </aside>
  );
}

function PresetGrid() {
  return (
    <div className="dash-grid">
      {PRESETS.map((preset) => (
        <article className="dash-card" key={preset.tag}>
          <div>
            <div className="dash-card-title">{preset.tag}</div>
            <p className="dash-card-copy">{preset.text}</p>
          </div>
          <div className="preset-actions">
            <button
              type="button"
              className="text-btn"
              onClick={() => {
                useStudio.setState({ prompt: preset.text, status: preset.tag });
                commitCode(preset.code);
              }}
            >
              Load
            </button>
            <button
              type="button"
              className="text-btn"
              onClick={() => {
                useStudio.setState({ prompt: preset.text, section: "prompt" });
              }}
            >
              Prompt
            </button>
          </div>
        </article>
      ))}
    </div>
  );
}

function SettingsPanel() {
  const autoRotate = useStudio((s) => s.autoRotate);
  const showGrid = useStudio((s) => s.showGrid);
  const showGizmo = useStudio((s) => s.showGizmo);
  const keyLight = useStudio((s) => s.keyLight);
  const roughness = useStudio((s) => s.roughness);
  const metalness = useStudio((s) => s.metalness);
  const tint = useStudio((s) => s.tint);

  return (
    <div className="settings-stack">
      <div className="dash-card">
        <div className="dash-card-title">Viewport</div>
        <div style={{ marginTop: 16 }}>
          <label className="check-row">
            Auto orbit
            <input
              type="checkbox"
              checked={autoRotate}
              onChange={(event) => useStudio.setState({ autoRotate: event.target.checked })}
            />
          </label>
          <label className="check-row">
            Grid
            <input
              type="checkbox"
              checked={showGrid}
              onChange={(event) => useStudio.setState({ showGrid: event.target.checked })}
            />
          </label>
          <label className="check-row">
            Gizmo
            <input
              type="checkbox"
              checked={showGizmo}
              onChange={(event) => useStudio.setState({ showGizmo: event.target.checked })}
            />
          </label>
          <label className="check-row">
            Key light
            <input
              type="range"
              min={0}
              max={3}
              step={0.05}
              value={keyLight}
              onChange={(event) =>
                useStudio.setState({ keyLight: Number(event.target.value), mode: "lighting" })
              }
            />
          </label>
        </div>
      </div>
      <div className="dash-card">
        <div className="dash-card-title">Material</div>
        <div style={{ marginTop: 16 }}>
          <label className="check-row">
            Roughness
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={roughness}
              onChange={(event) =>
                useStudio.setState({ roughness: Number(event.target.value), mode: "material" })
              }
            />
          </label>
          <label className="check-row">
            Metalness
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={metalness}
              onChange={(event) =>
                useStudio.setState({ metalness: Number(event.target.value), mode: "material" })
              }
            />
          </label>
          <label className="check-row">
            Tint
            <input
              className="color-input"
              type="color"
              value={tint}
              onChange={(event) => useStudio.setState({ tint: event.target.value, mode: "texture" })}
            />
          </label>
          <div className="settings-actions">
            <button type="button" className="text-btn" onClick={() => resetModel()}>
              New model
            </button>
            <button type="button" className="text-btn" onClick={() => clearSession()}>
              Clear session
            </button>
            <button type="button" className="text-btn" onClick={toggleFullscreen}>
              Fullscreen
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
