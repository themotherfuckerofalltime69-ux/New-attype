import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Dashboard } from "@/components/studio/Dashboard";
import { Landing } from "@/components/studio/Landing";
import { loadSession, saveSession, useStudio } from "@/lib/cad/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const entered = useStudio((s) => s.entered);
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    loadSession();
    if (reduce) useStudio.setState({ autoRotate: false });
    let timer = 0;
    const unsub = useStudio.subscribe(() => {
      window.clearTimeout(timer);
      timer = window.setTimeout(() => saveSession(), 300);
    });
    return () => {
      unsub();
      window.clearTimeout(timer);
    };
  }, []);

  if (entered) {
    return (
      <Dashboard
        onLeave={() => {
          setLeaving(false);
          useStudio.setState({ entered: false });
        }}
      />
    );
  }

  return (
    <Landing
      leaving={leaving}
      onProceed={() => {
        const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        if (reduce) {
          useStudio.setState({ entered: true });
          return;
        }
        setLeaving(true);
        window.setTimeout(() => useStudio.setState({ entered: true }), 300);
      }}
    />
  );
}
