import { PRESETS } from "@/lib/cad/scripts";
import { commitCode, useStudio } from "@/lib/cad/store";
import { generateToolpath } from "@/lib/cad/generate.functions";

export async function runGenerate() {
  const { prompt, sourceCode, modelTier, generating } = useStudio.getState();
  const text = prompt.trim();
  if (!text || generating) return;

  const started = performance.now();
  useStudio.setState({ generating: true, error: null, status: "Processing..." });

  try {
    const result = await generateToolpath({
      data: { prompt: text, currentCode: sourceCode, tier: modelTier },
    });
    const lastMs = Math.max(1, Math.round(performance.now() - started));
    if (!result.ok) {
      const preset = PRESETS.find((p) => p.text.toLowerCase() === text.toLowerCase());
      if (preset) {
        commitCode(preset.code);
        useStudio.setState({
          generating: false,
          lastMs,
          status: "Library part loaded",
          error: null,
        });
        return;
      }
      useStudio.setState({
        generating: false,
        lastMs,
        status: null,
        error: `AI Generation Failed:\n${result.error}`,
      });
      return;
    }
    commitCode(result.code);
    useStudio.setState({
      generating: false,
      lastMs,
      status: "Toolpath ready",
      error: null,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "AI generation failed.";
    useStudio.setState({
      generating: false,
      status: null,
      error: `AI Generation Failed:\n${message}`,
    });
  }
}
