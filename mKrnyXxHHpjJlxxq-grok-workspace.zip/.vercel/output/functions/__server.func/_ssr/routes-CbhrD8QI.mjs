import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as compileModel } from "./compile-BfDkv7iY.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CbhrD8QI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DEFAULT_PROMPT = "Mill high-performance radial turbine manifold with anodized finish.";
var DEFAULT_CODE = `
const group = new THREE.Group();

const baseGeo = new THREE.CylinderGeometry(1.5, 1.5, 0.3, 32);
const baseMat = new THREE.MeshStandardMaterial({
  color: 0xcccccc, metalness: 0.9, roughness: 0.25
});
const base = new THREE.Mesh(baseGeo, baseMat);
group.add(base);

const pillarGeo = new THREE.CylinderGeometry(0.5, 0.5, 1.5, 32);
const pillarMat = new THREE.MeshStandardMaterial({
  color: 0x111827, metalness: 0.8, roughness: 0.4
});
const pillar = new THREE.Mesh(pillarGeo, pillarMat);
pillar.position.y = 0.75;
group.add(pillar);

const numPegs = 8;
const radius = 1.1;
for (let i = 0; i < numPegs; i++) {
  const angle = (i / numPegs) * Math.PI * 2;
  const pegGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.6, 16);
  const pegMat = new THREE.MeshStandardMaterial({ color: 0x2563eb, metalness: 0.7, roughness: 0.2 });
  const peg = new THREE.Mesh(pegGeo, pegMat);
  peg.position.x = Math.cos(angle) * radius;
  peg.position.z = Math.sin(angle) * radius;
  peg.position.y = 0.3;
  group.add(peg);
}

return group;
`.trim();
var turbine = `
const group = new THREE.Group();
const metal = new THREE.MeshStandardMaterial({ color: 0xc5ccd6, metalness: 0.92, roughness: 0.22 });
const accent = new THREE.MeshStandardMaterial({ color: 0x2563eb, metalness: 0.75, roughness: 0.28 });
const dark = new THREE.MeshStandardMaterial({ color: 0x111827, metalness: 0.8, roughness: 0.35 });

const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.55, 0.9, 32), metal);
group.add(hub);

const shroud = new THREE.Mesh(new THREE.TorusGeometry(1.15, 0.18, 16, 48), dark);
shroud.rotation.x = Math.PI / 2;
group.add(shroud);

for (let i = 0; i < 12; i++) {
  const fin = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.72, 0.5), accent);
  const a = (i / 12) * Math.PI * 2;
  fin.position.set(Math.cos(a) * 0.82, 0, Math.sin(a) * 0.82);
  fin.lookAt(0, 0, 0);
  group.add(fin);
}

const nose = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.55, 28), metal);
nose.position.y = 0.7;
group.add(nose);

const duct = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 1.15, 20), dark);
duct.rotation.z = Math.PI / 2;
group.add(duct);

return group;
`.trim();
var cooling = `
const group = new THREE.Group();
const core = new THREE.Mesh(
  new THREE.CylinderGeometry(0.35, 0.35, 1.5, 28),
  new THREE.MeshStandardMaterial({ color: 0x1f2937, metalness: 0.82, roughness: 0.32 })
);
group.add(core);
const finMat = new THREE.MeshStandardMaterial({ color: 0x2563eb, metalness: 0.72, roughness: 0.24 });
for (let i = 0; i < 16; i++) {
  const fin = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.055, 0.38), finMat);
  const a = (i / 16) * Math.PI * 2;
  fin.position.set(Math.cos(a) * 0.72, 0, Math.sin(a) * 0.72);
  fin.rotation.y = -a;
  group.add(fin);
}
const cap = new THREE.Mesh(
  new THREE.CylinderGeometry(0.42, 0.42, 0.12, 28),
  new THREE.MeshStandardMaterial({ color: 0xd1d5db, metalness: 0.9, roughness: 0.2 })
);
cap.position.y = 0.78;
group.add(cap);
return group;
`.trim();
var stairs = `
const group = new THREE.Group();
const stepMat = new THREE.MeshStandardMaterial({ color: 0xd6dbe3, metalness: 0.62, roughness: 0.34 });
const railMat = new THREE.MeshStandardMaterial({ color: 0x111827, metalness: 0.86, roughness: 0.28 });
const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 3.3, 20), railMat);
group.add(pole);
const steps = 18;
for (let i = 0; i < steps; i++) {
  const step = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.07, 0.28), stepMat);
  const a = i * 0.55;
  step.position.set(Math.cos(a) * 0.72, -1.45 + i * 0.16, Math.sin(a) * 0.72);
  step.rotation.y = -a;
  group.add(step);
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.28, 8), railMat);
  post.position.set(Math.cos(a) * 1.05, -1.3 + i * 0.16, Math.sin(a) * 1.05);
  group.add(post);
}
return group;
`.trim();
var chamfer = `
const group = new THREE.Group();
const w = 2.1;
const d = 1.25;
const c = 0.2;
const shape = new THREE.Shape();
shape.moveTo(-w / 2 + c, -d / 2);
shape.lineTo(w / 2 - c, -d / 2);
shape.lineTo(w / 2, -d / 2 + c);
shape.lineTo(w / 2, d / 2 - c);
shape.lineTo(w / 2 - c, d / 2);
shape.lineTo(-w / 2 + c, d / 2);
shape.lineTo(-w / 2, d / 2 - c);
shape.lineTo(-w / 2, -d / 2 + c);
shape.closePath();
const geo = new THREE.ExtrudeGeometry(shape, {
  depth: 0.48,
  bevelEnabled: true,
  bevelThickness: 0.06,
  bevelSize: 0.05,
  bevelSegments: 2
});
geo.rotateX(-Math.PI / 2);
geo.translate(0, 0.18, 0);
const block = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({
  color: 0xe7ebf0, metalness: 0.95, roughness: 0.12
}));
group.add(block);
return group;
`.trim();
var bolts = `
const group = new THREE.Group();
const shape = new THREE.Shape();
shape.absarc(0, 0, 1.35, 0, Math.PI * 2, false);
for (let i = 0; i < 6; i++) {
  const a = (i / 6) * Math.PI * 2 - Math.PI / 2;
  const hole = new THREE.Path();
  hole.absarc(Math.cos(a) * 0.82, Math.sin(a) * 0.82, 0.13, 0, Math.PI * 2, true);
  shape.holes.push(hole);
}
const center = new THREE.Path();
center.absarc(0, 0, 0.28, 0, Math.PI * 2, true);
shape.holes.push(center);
const geo = new THREE.ExtrudeGeometry(shape, {
  depth: 0.22,
  bevelEnabled: true,
  bevelThickness: 0.025,
  bevelSize: 0.02,
  bevelSegments: 1
});
geo.rotateX(-Math.PI / 2);
geo.translate(0, 0.08, 0);
const plate = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({
  color: 0xd5dbe3, metalness: 0.9, roughness: 0.26
}));
group.add(plate);
return group;
`.trim();
var fluid = `
const group = new THREE.Group();
const shellMat = new THREE.MeshStandardMaterial({
  color: 0xc5ccd6, metalness: 0.9, roughness: 0.22, side: THREE.DoubleSide
});
const shell = new THREE.Mesh(new THREE.CylinderGeometry(0.58, 0.58, 2.2, 32, 1, true), shellMat);
group.add(shell);
const fluidMat = new THREE.MeshStandardMaterial({
  color: 0x2563eb, metalness: 0.35, roughness: 0.12, transparent: true, opacity: 0.88
});
const core = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 2.45, 24), fluidMat);
group.add(core);
const ringMat = new THREE.MeshStandardMaterial({ color: 0x111827, metalness: 0.8, roughness: 0.3 });
for (const y of [-0.72, 0.72]) {
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.58, 0.07, 12, 32), ringMat);
  ring.rotation.x = Math.PI / 2;
  ring.position.y = y;
  group.add(ring);
}
return group;
`.trim();
var honeycomb = `
const group = new THREE.Group();
const mat = new THREE.MeshStandardMaterial({ color: 0xe6ebf1, metalness: 0.86, roughness: 0.24 });
const edge = new THREE.MeshStandardMaterial({ color: 0x2563eb, metalness: 0.7, roughness: 0.3 });
const r = 0.22;
for (let q = -3; q <= 3; q++) {
  for (let row = -3; row <= 3; row++) {
    const x = q * r * 1.78;
    const z = row * r * 1.55 + (Math.abs(q) % 2) * r * 0.78;
    if (x * x + z * z > 1.55) continue;
    const cell = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.9, r * 0.9, 0.32, 6), mat);
    cell.position.set(x, 0, z);
    group.add(cell);
  }
}
const rim = new THREE.Mesh(new THREE.TorusGeometry(1.28, 0.06, 10, 40), edge);
rim.rotation.x = Math.PI / 2;
rim.position.y = 0.12;
group.add(rim);
return group;
`.trim();
var gear = `
const group = new THREE.Group();
const mat = new THREE.MeshStandardMaterial({ color: 0xb7c0cc, metalness: 0.92, roughness: 0.28 });
const dark = new THREE.MeshStandardMaterial({ color: 0x111827, metalness: 0.7, roughness: 0.35 });
const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.72, 0.72, 0.26, 40), mat);
group.add(hub);
const teeth = 24;
for (let i = 0; i < teeth; i++) {
  const tooth = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.26, 0.2), mat);
  const a = (i / teeth) * Math.PI * 2;
  tooth.position.set(Math.cos(a) * 0.86, 0, Math.sin(a) * 0.86);
  tooth.rotation.y = -a;
  group.add(tooth);
}
const bore = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.32, 20), dark);
group.add(bore);
const web = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.05, 8, 28), dark);
web.rotation.x = Math.PI / 2;
group.add(web);
return group;
`.trim();
var PRESETS = [
	{
		tag: "Turbine",
		text: "Mill high-performance radial turbine manifold with anodized finish.",
		code: turbine
	},
	{
		tag: "Cooling",
		text: "Add radial cooling fins around the central axis for heat dissipation.",
		code: cooling
	},
	{
		tag: "Architecture",
		text: "Sculpt spiraling staircase structure with filleted step edges.",
		code: stairs
	},
	{
		tag: "Chamfer",
		text: "Bevel outer edges with a 2mm chamfer and polished metal surface.",
		code: chamfer
	},
	{
		tag: "Mounting",
		text: "Drill array of 6 hexagonally patterned mounting bolt holes.",
		code: bolts
	},
	{
		tag: "Fluids",
		text: "Extrude central cylinder and generate internal hollow fluid channel.",
		code: fluid
	},
	{
		tag: "Aerospace",
		text: "Construct lightweight honeycomb infill matrix for aerospace component.",
		code: honeycomb
	},
	{
		tag: "Gears",
		text: "Machine high-precision spiral bevel gear set with 24 teeth.",
		code: gear
	}
];
var STORAGE_KEY = "typeless-studio-v1";
var SECTIONS = [
	"prompt",
	"blocks",
	"cad",
	"skilled",
	"settings"
];
var TOOLS = [
	"sel",
	"mov",
	"rot",
	"scl",
	"ext",
	"cut",
	"bvl",
	"dec"
];
var MODES = [
	"modeling",
	"sculpting",
	"texture",
	"vertex",
	"uv",
	"material",
	"lighting"
];
var commandSeq = 0;
var useStudio = create(() => ({
	entered: false,
	section: "prompt",
	sidebarCollapsed: false,
	prompt: DEFAULT_PROMPT,
	sourceCode: DEFAULT_CODE,
	revision: 0,
	activeTool: "dec",
	mode: "modeling",
	modelTier: "fast",
	ratio: 1,
	position: {
		x: 0,
		y: 0,
		z: 0
	},
	faceCount: 0,
	autoRotate: true,
	showGrid: true,
	showGizmo: true,
	keyLight: 1.2,
	roughness: .35,
	metalness: .8,
	tint: "#2563eb",
	generating: false,
	error: null,
	status: null,
	lastMs: null,
	command: null
}));
function issue(body) {
	commandSeq += 1;
	useStudio.setState({ command: {
		...body,
		id: commandSeq
	} });
}
function commitCode(code) {
	const revision = useStudio.getState().revision + 1;
	useStudio.setState({
		sourceCode: code,
		revision,
		error: null,
		status: null
	});
}
function resetModel() {
	const revision = useStudio.getState().revision + 1;
	useStudio.setState({
		prompt: DEFAULT_PROMPT,
		sourceCode: DEFAULT_CODE,
		revision,
		ratio: 1,
		position: {
			x: 0,
			y: 0,
			z: 0
		},
		mode: "modeling",
		activeTool: "dec",
		error: null,
		status: "New model",
		tint: "#2563eb"
	});
}
function isSection(value) {
	return typeof value === "string" && SECTIONS.includes(value);
}
function isTool(value) {
	return typeof value === "string" && TOOLS.includes(value);
}
function isMode(value) {
	return typeof value === "string" && MODES.includes(value);
}
function isTier(value) {
	return value === "fast" || value === "advanced";
}
function loadSession() {
	if (typeof window === "undefined") return false;
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return false;
		const data = JSON.parse(raw);
		const patch = {};
		if (typeof data.prompt === "string") patch.prompt = data.prompt.slice(0, 2e3);
		if (typeof data.sourceCode === "string" && data.sourceCode.includes("return")) patch.sourceCode = data.sourceCode.slice(0, 2e4);
		if (typeof data.ratio === "number" && Number.isFinite(data.ratio)) patch.ratio = Math.min(2, Math.max(.05, data.ratio));
		if (typeof data.autoRotate === "boolean") patch.autoRotate = data.autoRotate;
		if (typeof data.showGrid === "boolean") patch.showGrid = data.showGrid;
		if (typeof data.showGizmo === "boolean") patch.showGizmo = data.showGizmo;
		if (typeof data.sidebarCollapsed === "boolean") patch.sidebarCollapsed = data.sidebarCollapsed;
		if (isSection(data.section)) patch.section = data.section;
		if (isTool(data.activeTool)) patch.activeTool = data.activeTool;
		if (isMode(data.mode)) patch.mode = data.mode;
		if (isTier(data.modelTier)) patch.modelTier = data.modelTier;
		if (typeof data.keyLight === "number") patch.keyLight = data.keyLight;
		if (typeof data.roughness === "number") patch.roughness = data.roughness;
		if (typeof data.metalness === "number") patch.metalness = data.metalness;
		if (typeof data.tint === "string" && /^#[0-9a-fA-F]{6}$/.test(data.tint)) patch.tint = data.tint;
		useStudio.setState(patch);
		return true;
	} catch {
		return false;
	}
}
function saveSession() {
	if (typeof window === "undefined") return;
	const s = useStudio.getState();
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify({
			prompt: s.prompt,
			sourceCode: s.sourceCode,
			ratio: s.ratio,
			autoRotate: s.autoRotate,
			showGrid: s.showGrid,
			showGizmo: s.showGizmo,
			sidebarCollapsed: s.sidebarCollapsed,
			section: s.section,
			activeTool: s.activeTool,
			mode: s.mode,
			modelTier: s.modelTier,
			keyLight: s.keyLight,
			roughness: s.roughness,
			metalness: s.metalness,
			tint: s.tint
		}));
	} catch {}
}
function clearSession() {
	if (typeof window !== "undefined") localStorage.removeItem(STORAGE_KEY);
	resetModel();
	useStudio.setState({
		section: "settings",
		sidebarCollapsed: false,
		autoRotate: true,
		showGrid: true,
		showGizmo: true,
		keyLight: 1.2,
		roughness: .35,
		metalness: .8,
		modelTier: "fast",
		lastMs: null
	});
}
function toggleFullscreen() {
	if (typeof document === "undefined") return;
	if (!document.fullscreenElement) document.documentElement.requestFullscreen().catch(() => {});
	else if (document.exitFullscreen) document.exitFullscreen();
}
function downloadScript() {
	const code = useStudio.getState().sourceCode;
	const blob = new Blob([code], { type: "text/javascript" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = "typeless-toolpath.js";
	a.click();
	URL.revokeObjectURL(url);
}
var SECTION_TITLES = [
	{
		id: "prompt",
		title: "typeless prompt"
	},
	{
		id: "blocks",
		title: "component blocks"
	},
	{
		id: "cad",
		title: "image/CAD"
	},
	{
		id: "skilled",
		title: "/Skilled"
	},
	{
		id: "settings",
		title: "Settings"
	}
];
var TOOL_LIST = [
	{
		id: "sel",
		label: "sel",
		title: "Select"
	},
	{
		id: "mov",
		label: "mov",
		title: "Move"
	},
	{
		id: "rot",
		label: "rot",
		title: "Rotate"
	},
	{
		id: "scl",
		label: "scl",
		title: "Scale"
	},
	{
		id: "ext",
		label: "ext",
		title: "Extrude"
	},
	{
		id: "cut",
		label: "cut",
		title: "Loop Cut"
	},
	{
		id: "bvl",
		label: "bvl",
		title: "Bevel"
	},
	{
		id: "dec",
		label: "dec",
		title: "Decimate"
	}
];
var MODE_LIST = [
	{
		id: "modeling",
		label: "Modeling"
	},
	{
		id: "sculpting",
		label: "Sculpting"
	},
	{
		id: "texture",
		label: "Texture paint"
	},
	{
		id: "vertex",
		label: "Vertex paint"
	},
	{
		id: "uv",
		label: "UV editor"
	},
	{
		id: "material",
		label: "Material"
	},
	{
		id: "lighting",
		label: "Lighting"
	}
];
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var generateToolpath = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") throw new Error("Missing prompt.");
	const prompt = "prompt" in input && typeof input.prompt === "string" ? input.prompt.trim() : "";
	const currentCode = "currentCode" in input && typeof input.currentCode === "string" ? input.currentCode : "";
	const tier = "tier" in input && input.tier === "advanced" ? "advanced" : "fast";
	if (prompt.length < 1 || prompt.length > 2e3) throw new Error("Prompt must be 1–2000 characters.");
	return {
		prompt,
		currentCode: currentCode.slice(0, 12e3),
		tier
	};
}).handler(createSsrRpc("d49c3a3d8e5265e8b0a523551ac660da1bbc424bf80627ca37da95a9de7f1efc"));
async function runGenerate() {
	const { prompt, sourceCode, modelTier, generating } = useStudio.getState();
	const text = prompt.trim();
	if (!text || generating) return;
	const started = performance.now();
	useStudio.setState({
		generating: true,
		error: null,
		status: "Processing..."
	});
	try {
		const result = await generateToolpath({ data: {
			prompt: text,
			currentCode: sourceCode,
			tier: modelTier
		} });
		const lastMs = Math.max(1, Math.round(performance.now() - started));
		if (!result.ok) {
			const preset = PRESETS.find((p) => p.text.toLowerCase() === text.toLowerCase());
			if (preset) {
				commitCode(preset.code);
				useStudio.setState({
					generating: false,
					lastMs,
					status: "Library part loaded",
					error: null
				});
				return;
			}
			useStudio.setState({
				generating: false,
				lastMs,
				status: null,
				error: `AI Generation Failed:\n${result.error}`
			});
			return;
		}
		commitCode(result.code);
		useStudio.setState({
			generating: false,
			lastMs,
			status: "Toolpath ready",
			error: null
		});
	} catch (err) {
		const message = err instanceof Error ? err.message : "AI generation failed.";
		useStudio.setState({
			generating: false,
			status: null,
			error: `AI Generation Failed:\n${message}`
		});
	}
}
function round2(n) {
	return Math.round(n * 100) / 100;
}
function Viewport() {
	const hostRef = (0, import_react.useRef)(null);
	const error = useStudio((s) => s.error);
	const showGizmo = useStudio((s) => s.showGizmo);
	const faceCount = useStudio((s) => s.faceCount);
	(0, import_react.useEffect)(() => {
		const host = hostRef.current;
		if (!host) return;
		let dead = false;
		let raf = 0;
		let cleanup = () => {};
		(async () => {
			const THREE = await import("../_libs/three.mjs").then((n) => n.t);
			if (dead) return;
			const scene = new THREE.Scene();
			scene.background = new THREE.Color(593174);
			scene.fog = new THREE.FogExp2(593174, .035);
			const camera = new THREE.PerspectiveCamera(45, 1, .1, 100);
			const renderer = new THREE.WebGLRenderer({
				antialias: true,
				preserveDrawingBuffer: true
			});
			renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
			renderer.shadowMap.enabled = true;
			renderer.shadowMap.type = THREE.PCFShadowMap;
			renderer.domElement.className = "webgl-canvas";
			host.appendChild(renderer.domElement);
			scene.add(new THREE.AmbientLight(16777215, .6));
			const dir1 = new THREE.DirectionalLight(16777215, useStudio.getState().keyLight);
			dir1.position.set(5, 10, 7);
			dir1.castShadow = true;
			dir1.shadow.mapSize.set(1024, 1024);
			scene.add(dir1);
			const dir2 = new THREE.DirectionalLight(2450411, .8);
			dir2.position.set(-5, 5, -5);
			scene.add(dir2);
			const grid = new THREE.GridHelper(20, 40, 3621201, 2042167);
			grid.position.y = -1.5;
			grid.visible = useStudio.getState().showGrid;
			scene.add(grid);
			const ground = new THREE.Mesh(new THREE.PlaneGeometry(30, 30), new THREE.ShadowMaterial({ opacity: .38 }));
			ground.rotation.x = -Math.PI / 2;
			ground.position.y = -1.5;
			ground.receiveShadow = true;
			scene.add(ground);
			let group = null;
			let applying = false;
			let seenRev = -1;
			let seenCmd = -1;
			let autoRotate = useStudio.getState().autoRotate;
			let dragging = false;
			let previous = {
				x: 0,
				y: 0
			};
			const targetRotation = {
				x: .5,
				y: .8
			};
			const currentRotation = {
				x: .5,
				y: .8
			};
			let cameraRadius = 8;
			let touchStartDist = 0;
			function disposeObject(obj) {
				obj.traverse((child) => {
					const mesh = child;
					if (mesh.geometry) mesh.geometry.dispose();
					const material = mesh.material;
					if (Array.isArray(material)) material.forEach((m) => m.dispose());
					else if (material) material.dispose();
				});
			}
			function countFaces(root) {
				let count = 0;
				root.traverse((child) => {
					const mesh = child;
					if (!mesh.isMesh || !mesh.geometry) return;
					if (mesh.geometry.index) count += mesh.geometry.index.count / 3;
					else {
						const pos = mesh.geometry.getAttribute("position");
						if (pos) count += pos.count / 3;
					}
				});
				return Math.floor(count);
			}
			function publishStats() {
				if (!group) return;
				applying = true;
				useStudio.setState({
					faceCount: countFaces(group),
					position: {
						x: round2(group.position.x),
						y: round2(group.position.y),
						z: round2(group.position.z)
					}
				});
				applying = false;
			}
			function eachMaterial(root, visit) {
				root.traverse((child) => {
					const mesh = child;
					if (!mesh.isMesh || !mesh.material) return;
					const list = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
					for (const mat of list) visit(mat, mesh);
				});
			}
			let lastMode = "";
			function applyLook(s) {
				if (!group) return;
				const modeChanged = s.mode !== lastMode;
				lastMode = s.mode;
				eachMaterial(group, (mat) => {
					if (!("color" in mat) || !("roughness" in mat)) return;
					const std = mat;
					if (std.userData.baseColor == null) {
						std.userData.baseColor = std.color.getHex();
						std.userData.baseRough = std.roughness;
						std.userData.baseMetal = std.metalness;
					}
					if ("wireframe" in std) std.wireframe = s.mode === "sculpting" || s.mode === "uv";
					if (s.mode === "texture") std.color.set(s.tint);
					else if (modeChanged && typeof std.userData.baseColor === "number") std.color.setHex(std.userData.baseColor);
					if (s.mode === "material") {
						std.roughness = s.roughness;
						std.metalness = s.metalness;
					} else if (modeChanged && typeof std.userData.baseRough === "number") {
						std.roughness = std.userData.baseRough;
						std.metalness = std.userData.baseMetal;
					}
				});
			}
			function tagShadows(root) {
				root.traverse((child) => {
					const mesh = child;
					if (!mesh.isMesh) return;
					mesh.castShadow = true;
					mesh.receiveShadow = true;
				});
			}
			function rebuild(code) {
				const next = compileModel(THREE, code);
				if (group) {
					scene.remove(group);
					disposeObject(group);
				}
				const ratio = useStudio.getState().ratio;
				next.scale.set(ratio, ratio, ratio);
				next.position.set(0, 0, 0);
				next.rotation.set(0, 0, 0);
				tagShadows(next);
				group = next;
				scene.add(group);
				applyLook(useStudio.getState());
			}
			function tryCompile(code) {
				try {
					lastMode = "";
					rebuild(code);
					applying = true;
					useStudio.setState({ error: null });
					applying = false;
					publishStats();
				} catch (err) {
					const message = err instanceof Error ? err.message : "Compilation failed";
					applying = true;
					useStudio.setState({
						error: `Compilation/Execution Error:\n${message}`,
						status: null
					});
					applying = false;
				}
			}
			function paintVertices() {
				if (!group) return;
				group.traverse((child) => {
					const mesh = child;
					if (!mesh.isMesh || !mesh.geometry) return;
					const pos = mesh.geometry.getAttribute("position");
					if (!pos) return;
					const colors = new THREE.BufferAttribute(new Float32Array(pos.count * 3), 3);
					for (let i = 0; i < pos.count; i++) {
						const y = pos.getY(i);
						const t = Math.min(1, Math.max(0, (y + 1.5) / 3));
						colors.setXYZ(i, .05, .55 + t * .4, 1);
					}
					mesh.geometry.setAttribute("color", colors);
					const list = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
					for (const mat of list) if (mat && "vertexColors" in mat) {
						mat.vertexColors = true;
						mat.needsUpdate = true;
					}
				});
			}
			function runTool(tool) {
				if (!group) return;
				if (tool === "mov") group.position.y += .2;
				if (tool === "rot") group.rotation.y += Math.PI / 8;
				if (tool === "scl") {
					group.scale.multiplyScalar(1.1);
					applying = true;
					useStudio.setState({ ratio: Math.min(3, round2(group.scale.x)) });
					applying = false;
				}
				if (tool === "ext") group.traverse((child) => {
					const mesh = child;
					if (!mesh.isMesh || !mesh.geometry) return;
					const geo = mesh.geometry;
					geo.computeVertexNormals();
					const pos = geo.getAttribute("position");
					const normal = geo.getAttribute("normal");
					if (!pos || !normal) return;
					for (let i = 0; i < pos.count; i++) pos.setXYZ(i, pos.getX(i) + normal.getX(i) * .05, pos.getY(i) + normal.getY(i) * .05, pos.getZ(i) + normal.getZ(i) * .05);
					pos.needsUpdate = true;
					geo.computeVertexNormals();
					geo.computeBoundingSphere();
				});
				if (tool === "cut") group.traverse((child) => {
					const mesh = child;
					if (!mesh.isMesh || !mesh.geometry || mesh.userData.cut) return;
					const lines = new THREE.LineSegments(new THREE.WireframeGeometry(mesh.geometry), new THREE.LineBasicMaterial({ color: 61695 }));
					mesh.add(lines);
					mesh.userData.cut = true;
				});
				if (tool === "bvl") eachMaterial(group, (mat) => {
					if (!("roughness" in mat) || !("metalness" in mat)) return;
					const std = mat;
					std.roughness = Math.max(0, std.roughness - .1);
					std.metalness = Math.min(1, std.metalness + .1);
				});
				if (tool === "dec") {
					group.scale.set(1, 1, 1);
					applying = true;
					useStudio.setState({ ratio: 1 });
					applying = false;
				}
				publishStats();
			}
			function runCommand(command) {
				if (command.kind === "tool") runTool(command.tool);
				if (command.kind === "scale" && group) {
					const ratio = Math.min(3, Math.max(.05, command.ratio));
					group.scale.set(ratio, ratio, ratio);
					publishStats();
				}
				if (command.kind === "position" && group) {
					group.position.set(command.x, command.y, command.z);
					publishStats();
				}
				if (command.kind === "reset-camera") {
					targetRotation.x = .5;
					targetRotation.y = .8;
					cameraRadius = 8;
				}
				if (command.kind === "screenshot") {
					const url = renderer.domElement.toDataURL("image/png");
					const a = document.createElement("a");
					a.href = url;
					a.download = "typeless-viewport.png";
					a.click();
				}
				if (command.kind === "vertex") paintVertices();
			}
			function resize() {
				if (!host) return;
				const w = host.clientWidth;
				const h = host.clientHeight;
				if (w < 2 || h < 2) return;
				camera.aspect = w / h;
				camera.updateProjectionMatrix();
				renderer.setSize(w, h, false);
			}
			function sync(s) {
				if (applying) return;
				autoRotate = s.autoRotate;
				grid.visible = s.showGrid;
				dir1.intensity = s.keyLight;
				if (s.revision !== seenRev) {
					const first = seenRev < 0;
					seenRev = s.revision;
					tryCompile(s.sourceCode);
					if (!first && host) {
						const rect = host.getBoundingClientRect();
						if (Math.min(rect.bottom, window.innerHeight) - Math.max(rect.top, 0) < 140) {
							const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
							host.scrollIntoView({
								block: "nearest",
								behavior: reduce ? "auto" : "smooth"
							});
						}
					}
				}
				applyLook(s);
				if (s.command && s.command.id !== seenCmd) {
					seenCmd = s.command.id;
					runCommand(s.command);
				}
			}
			const unsub = useStudio.subscribe(sync);
			sync(useStudio.getState());
			resize();
			const observer = new ResizeObserver(() => resize());
			observer.observe(host);
			function onPointerDown(e) {
				if (e.pointerType === "touch") return;
				dragging = true;
				previous = {
					x: e.clientX,
					y: e.clientY
				};
			}
			function onPointerMove(e) {
				if (!dragging || e.pointerType === "touch") return;
				const dx = e.clientX - previous.x;
				const dy = e.clientY - previous.y;
				targetRotation.y += dx * .005;
				targetRotation.x += dy * .005;
				targetRotation.x = Math.max(-Math.PI / 2 + .01, Math.min(Math.PI / 2 - .01, targetRotation.x));
				previous = {
					x: e.clientX,
					y: e.clientY
				};
			}
			function onPointerUp() {
				dragging = false;
			}
			function onWheel(e) {
				e.preventDefault();
				cameraRadius += e.deltaY * .005;
				cameraRadius = Math.max(3, Math.min(20, cameraRadius));
			}
			function onTouchStart(e) {
				if (e.touches.length === 1) {
					dragging = true;
					previous = {
						x: e.touches[0].clientX,
						y: e.touches[0].clientY
					};
				} else if (e.touches.length === 2) {
					dragging = false;
					touchStartDist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
				}
			}
			function onTouchMove(e) {
				if (dragging && e.touches.length === 1) {
					const dx = e.touches[0].clientX - previous.x;
					const dy = e.touches[0].clientY - previous.y;
					targetRotation.y += dx * .005;
					targetRotation.x += dy * .005;
					targetRotation.x = Math.max(-Math.PI / 2 + .01, Math.min(Math.PI / 2 - .01, targetRotation.x));
					previous = {
						x: e.touches[0].clientX,
						y: e.touches[0].clientY
					};
				} else if (e.touches.length === 2) {
					const dist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
					cameraRadius += (touchStartDist - dist) * .01;
					cameraRadius = Math.max(3, Math.min(20, cameraRadius));
					touchStartDist = dist;
				}
			}
			function onTouchEnd() {
				dragging = false;
			}
			host.addEventListener("pointerdown", onPointerDown);
			window.addEventListener("pointermove", onPointerMove);
			window.addEventListener("pointerup", onPointerUp);
			host.addEventListener("wheel", onWheel, { passive: false });
			host.addEventListener("touchstart", onTouchStart, { passive: true });
			host.addEventListener("touchmove", onTouchMove, { passive: true });
			host.addEventListener("touchend", onTouchEnd);
			function animate() {
				raf = requestAnimationFrame(animate);
				if (!dragging && autoRotate) targetRotation.y += .002;
				currentRotation.x += (targetRotation.x - currentRotation.x) * .1;
				currentRotation.y += (targetRotation.y - currentRotation.y) * .1;
				camera.position.x = cameraRadius * Math.sin(currentRotation.y) * Math.cos(currentRotation.x);
				camera.position.y = cameraRadius * Math.sin(currentRotation.x);
				camera.position.z = cameraRadius * Math.cos(currentRotation.y) * Math.cos(currentRotation.x);
				camera.lookAt(0, 0, 0);
				renderer.render(scene, camera);
			}
			animate();
			cleanup = () => {
				cancelAnimationFrame(raf);
				unsub();
				observer.disconnect();
				host.removeEventListener("pointerdown", onPointerDown);
				window.removeEventListener("pointermove", onPointerMove);
				window.removeEventListener("pointerup", onPointerUp);
				host.removeEventListener("wheel", onWheel);
				host.removeEventListener("touchstart", onTouchStart);
				host.removeEventListener("touchmove", onTouchMove);
				host.removeEventListener("touchend", onTouchEnd);
				if (group) disposeObject(group);
				ground.geometry.dispose();
				ground.material.dispose();
				renderer.dispose();
				renderer.domElement.remove();
			};
		})();
		return () => {
			dead = true;
			cleanup();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "viewport",
		ref: hostRef,
		role: "img",
		"aria-label": "3D viewport. Drag to orbit, scroll or pinch to zoom.",
		children: [
			showGizmo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "viewport-gizmo",
				children: "XYZ"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "viewport-faces",
				children: [faceCount.toLocaleString(), " faces"]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "error-console",
				role: "alert",
				children: error
			}) : null
		]
	});
}
function go(section) {
	useStudio.setState({ section });
}
function selectMode(mode) {
	useStudio.setState({ mode });
	if (mode === "vertex") issue({ kind: "vertex" });
}
function Dashboard({ onLeave }) {
	const section = useStudio((s) => s.section);
	const collapsed = useStudio((s) => s.sidebarCollapsed);
	const title = SECTION_TITLES.find((item) => item.id === section)?.title ?? "typeless prompt";
	const bodyRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		bodyRef.current?.scrollTo({ top: 0 });
	}, [section]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "dashboard-view active",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: collapsed ? "sidebar collapsed" : "sidebar",
			id: "sidebar",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sidebar-top",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sidebar-brand",
					children: "Typeless"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "collapse-btn",
					title: "Toggle Menu",
					onClick: () => useStudio.setState({ sidebarCollapsed: !collapsed }),
					children: "<>"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "sidebar-menu",
				children: SECTION_TITLES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: section === item.id ? "sidebar-item active" : "sidebar-item",
					onClick: () => go(item.id),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.title })
				}) }, item.id))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "dashboard-main",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "dash-header",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "logo-tag",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sparkle",
							children: "+"
						}),
						"// ",
						title.toUpperCase(),
						" //"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "back-btn",
					onClick: onLeave,
					children: ["<<", " Return"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: bodyRef,
				className: section === "settings" ? "dash-body is-settings" : "dash-body",
				children: [section === "prompt" || section === "skilled" || section === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "section-pane",
					children: [
						section === "prompt" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatGrid, {}) : null,
						section === "skilled" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresetGrid, {}) : null,
						section === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPanel, {}) : null
					]
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: section === "settings" ? "studio parked" : "studio",
					"aria-label": "Modeling workspace",
					inert: section === "settings" ? true : void 0,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioNav, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeBar, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeExtras, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "workspace",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Viewport, {}), section === "prompt" || section === "blocks" || section === "cad" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rail",
								children: [
									section === "prompt" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromptSidebar, {}) : null,
									section === "prompt" || section === "blocks" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolsSidebar, {}) : null,
									section === "cad" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CadSidebar, {}) : null
								]
							}) : null]
						})
					]
				})]
			})]
		})]
	});
}
function StatGrid() {
	const faces = useStudio((s) => s.faceCount);
	const lastMs = useStudio((s) => s.lastMs);
	const generating = useStudio((s) => s.generating);
	const error = useStudio((s) => s.error);
	const throughput = generating ? "…" : error ? "ERR" : "100%";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "dash-grid stats-grid",
		id: "dashGrid",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "dash-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "dash-card-title",
					children: "Active Nodes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "dash-card-value",
					children: faces.toLocaleString()
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "dash-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "dash-card-title",
					children: "Latency"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "dash-card-value",
					children: lastMs == null ? "—" : `${lastMs}ms`
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "dash-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "dash-card-title",
					children: "Throughput"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "dash-card-value",
					children: throughput
				})]
			})
		]
	});
}
function StudioNav() {
	const [open, setOpen] = (0, import_react.useState)(null);
	const showGrid = useStudio((s) => s.showGrid);
	const showGizmo = useStudio((s) => s.showGizmo);
	const autoRotate = useStudio((s) => s.autoRotate);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const close = () => setOpen(null);
		window.addEventListener("pointerdown", close);
		return () => window.removeEventListener("pointerdown", close);
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "topnav",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nav-left",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: open === "file" ? "nav-slot open" : "nav-slot",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "nav-item",
						onPointerDown: (event) => event.stopPropagation(),
						onClick: () => setOpen(open === "file" ? null : "file"),
						children: ["File ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "nav-caret",
							children: "▼"
						})]
					}), open === "file" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "nav-menu",
						onPointerDown: (event) => event.stopPropagation(),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									resetModel();
									setOpen(null);
								},
								children: "New model"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									downloadScript();
									setOpen(null);
								},
								children: "Export script"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									issue({ kind: "screenshot" });
									setOpen(null);
								},
								children: "Save screenshot"
							})
						]
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: open === "interface" ? "nav-slot open" : "nav-slot",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "nav-item",
						onPointerDown: (event) => event.stopPropagation(),
						onClick: () => setOpen(open === "interface" ? null : "interface"),
						children: ["Interface ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "nav-caret",
							children: "▼"
						})]
					}), open === "interface" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "nav-menu",
						onPointerDown: (event) => event.stopPropagation(),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => useStudio.setState({ showGrid: !showGrid }),
								children: showGrid ? "Hide grid" : "Show grid"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => useStudio.setState({ showGizmo: !showGizmo }),
								children: showGizmo ? "Hide gizmo" : "Show gizmo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => useStudio.setState({ autoRotate: !autoRotate }),
								children: autoRotate ? "Stop orbit" : "Auto orbit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									issue({ kind: "reset-camera" });
									setOpen(null);
								},
								children: "Reset camera"
							})
						]
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "nav-item",
					onClick: () => go("settings"),
					children: "Settings"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "nav-right",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nav-item brand-mark",
				children: "◇ AI CNC"
			})
		})]
	});
}
function ModeBar() {
	const mode = useStudio((s) => s.mode);
	const section = useStudio((s) => s.section);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		className: "modebar",
		"aria-label": "Modeling modes",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: section === "skilled" ? "mode-btn library active" : "mode-btn library",
				onClick: () => go("skilled"),
				children: "+M Library"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: section === "blocks" ? "mode-btn active" : "mode-btn",
				onClick: () => go("blocks"),
				children: "Tools"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "modebar-divider" }),
			MODE_LIST.slice(0, 5).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: mode === item.id ? "mode-btn active" : "mode-btn",
				onClick: () => selectMode(item.id),
				children: item.label
			}, item.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "modebar-divider" }),
			MODE_LIST.slice(5).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: mode === item.id ? "mode-btn active" : "mode-btn",
				onClick: () => selectMode(item.id),
				children: item.label
			}, item.id))
		]
	});
}
function ModeExtras() {
	const mode = useStudio((s) => s.mode);
	const roughness = useStudio((s) => s.roughness);
	const metalness = useStudio((s) => s.metalness);
	const keyLight = useStudio((s) => s.keyLight);
	const tint = useStudio((s) => s.tint);
	if (mode === "material") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mode-extra",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Roughness", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "range",
			min: 0,
			max: 1,
			step: .01,
			value: roughness,
			onChange: (event) => useStudio.setState({ roughness: Number(event.target.value) })
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Metal", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "range",
			min: 0,
			max: 1,
			step: .01,
			value: metalness,
			onChange: (event) => useStudio.setState({ metalness: Number(event.target.value) })
		})] })]
	});
	if (mode === "lighting") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mode-extra",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Key light", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "range",
			min: 0,
			max: 3,
			step: .05,
			value: keyLight,
			onChange: (event) => useStudio.setState({ keyLight: Number(event.target.value) })
		})] })
	});
	if (mode === "texture") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mode-extra",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Tint", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "color-input",
			type: "color",
			value: tint,
			onChange: (event) => useStudio.setState({ tint: event.target.value })
		})] })
	});
	return null;
}
function PromptSidebar() {
	const prompt = useStudio((s) => s.prompt);
	const tier = useStudio((s) => s.modelTier);
	const generating = useStudio((s) => s.generating);
	const status = useStudio((s) => s.status);
	const [matches, setMatches] = (0, import_react.useState)([]);
	function onPrompt(value) {
		useStudio.setState({ prompt: value });
		const query = value.toLowerCase().trim();
		if (!query) {
			setMatches([]);
			return;
		}
		setMatches(PRESETS.filter((preset) => preset.text.toLowerCase().includes(query) && preset.text.toLowerCase() !== query));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
		className: "tool-sidebar",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sidebar-section",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sidebar-title",
				children: "AI Prompt Generator"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ai-prompt-box",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "sr-only",
						htmlFor: "ai-model-select",
						children: "Model"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						id: "ai-model-select",
						className: "ai-select",
						value: tier,
						onChange: (event) => useStudio.setState({ modelTier: event.target.value === "advanced" ? "advanced" : "fast" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "fast",
							children: "Grok 4.5 (Fast)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "advanced",
							children: "Grok 4.5 (Advanced)"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "sr-only",
						htmlFor: "ai-prompt-input",
						children: "Prompt"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "ai-textarea",
						id: "ai-prompt-input",
						autoComplete: "off",
						spellCheck: false,
						maxLength: 2e3,
						placeholder: "Describe CNC part modification (e.g., add radial cooling fins, spiraling staircase)...",
						value: prompt,
						onChange: (event) => onPrompt(event.target.value)
					}),
					matches.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "ai-suggestions",
						id: "ai-suggestions",
						children: matches.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "ai-suggestion-item",
							onClick: () => {
								useStudio.setState({ prompt: preset.text });
								setMatches([]);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: preset.text }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tag",
								children: preset.tag
							})]
						}, preset.tag))
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "ai-btn",
						id: "ai-generate-btn",
						disabled: generating || prompt.trim().length === 0,
						onClick: () => void runGenerate(),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: generating ? "" : "⚡" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: generating ? "spinner" : "sr-only",
								children: "⚙"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: generating ? "Processing..." : "Generate Toolpath" })
						]
					}),
					status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "status-line",
						children: status
					}) : null
				]
			})]
		})
	});
}
function CadSidebar() {
	const showGrid = useStudio((s) => s.showGrid);
	const showGizmo = useStudio((s) => s.showGizmo);
	const autoRotate = useStudio((s) => s.autoRotate);
	const faces = useStudio((s) => s.faceCount);
	const keyLight = useStudio((s) => s.keyLight);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "tool-sidebar",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sidebar-section",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sidebar-title",
						children: "CAD View"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "prop-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "prop-label",
							children: "Faces"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							style: { fontWeight: 500 },
							children: faces.toLocaleString()
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "status-line",
						style: { marginTop: 8 },
						children: "Drag to orbit. Scroll or pinch to zoom."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sidebar-section",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sidebar-title",
					children: "Image"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "settings-actions",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "ai-btn",
						onClick: () => issue({ kind: "screenshot" }),
						children: "Save image"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "ai-btn",
						onClick: () => issue({ kind: "reset-camera" }),
						children: "Reset camera"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sidebar-section",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sidebar-title",
						children: "Display"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "prop-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "prop-label",
							children: "Grid"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: showGrid,
							onChange: (event) => useStudio.setState({ showGrid: event.target.checked })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "prop-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "prop-label",
							children: "Gizmo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: showGizmo,
							onChange: (event) => useStudio.setState({ showGizmo: event.target.checked })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "prop-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "prop-label",
							children: "Auto orbit"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: autoRotate,
							onChange: (event) => useStudio.setState({ autoRotate: event.target.checked })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "prop-row",
						style: { marginTop: 10 },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "prop-label",
							children: "Key light"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: 0,
						max: 3,
						step: .05,
						value: keyLight,
						"aria-label": "Key light",
						onChange: (event) => useStudio.setState({ keyLight: Number(event.target.value) })
					})
				]
			})
		]
	});
}
function ToolsSidebar() {
	const activeTool = useStudio((s) => s.activeTool);
	const ratio = useStudio((s) => s.ratio);
	const faces = useStudio((s) => s.faceCount);
	const position = useStudio((s) => s.position);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "tool-sidebar",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sidebar-section",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sidebar-title",
					children: "Active Tools"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "tool-grid",
					id: "tool-grid",
					children: TOOL_LIST.map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: activeTool === tool.id ? "tool-icon active" : "tool-icon",
						title: tool.title,
						onClick: () => {
							useStudio.setState({ activeTool: tool.id });
							issue({
								kind: "tool",
								tool: tool.id
							});
						},
						children: tool.label
					}, tool.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sidebar-section",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sidebar-title",
						children: "Decimate Modifier"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "prop-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "prop-label",
							children: "Ratio"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							className: "prop-value",
							"aria-label": "Decimate ratio",
							value: ratio.toFixed(2),
							onChange: (event) => {
								const next = Number(event.target.value);
								if (!Number.isFinite(next)) return;
								const clamped = Math.min(2, Math.max(.05, next));
								useStudio.setState({ ratio: clamped });
								issue({
									kind: "scale",
									ratio: clamped
								});
							}
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: .05,
						max: 1,
						step: .05,
						value: Math.min(1, ratio),
						"aria-label": "Decimate ratio slider",
						onChange: (event) => {
							const next = Number(event.target.value);
							useStudio.setState({ ratio: next });
							issue({
								kind: "scale",
								ratio: next
							});
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "prop-row",
						style: { marginTop: 10 },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "prop-label",
							children: "Faces"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							style: { fontWeight: 500 },
							children: faces.toLocaleString()
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sidebar-section",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sidebar-title",
					children: "Transform"
				}), [
					"x",
					"y",
					"z"
				].map((axis) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "prop-row",
					style: axis === "x" ? void 0 : { marginTop: 6 },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "prop-label",
						children: ["Position ", axis.toUpperCase()]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						className: "prop-value",
						"aria-label": `Position ${axis.toUpperCase()}`,
						value: `${position[axis].toFixed(2)} m`,
						onChange: (event) => {
							const next = Number.parseFloat(event.target.value);
							if (!Number.isFinite(next)) return;
							const positionNext = {
								...useStudio.getState().position,
								[axis]: next
							};
							useStudio.setState({ position: positionNext });
							issue({
								kind: "position",
								...positionNext
							});
						}
					})]
				}, axis))]
			})
		]
	});
}
function PresetGrid() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "dash-grid",
		children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "dash-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "dash-card-title",
				children: preset.tag
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "dash-card-copy",
				children: preset.text
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "preset-actions",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-btn",
					onClick: () => {
						useStudio.setState({
							prompt: preset.text,
							status: preset.tag
						});
						commitCode(preset.code);
					},
					children: "Load"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-btn",
					onClick: () => {
						useStudio.setState({
							prompt: preset.text,
							section: "prompt"
						});
					},
					children: "Prompt"
				})]
			})]
		}, preset.tag))
	});
}
function SettingsPanel() {
	const autoRotate = useStudio((s) => s.autoRotate);
	const showGrid = useStudio((s) => s.showGrid);
	const showGizmo = useStudio((s) => s.showGizmo);
	const keyLight = useStudio((s) => s.keyLight);
	const roughness = useStudio((s) => s.roughness);
	const metalness = useStudio((s) => s.metalness);
	const tint = useStudio((s) => s.tint);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "settings-stack",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "dash-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "dash-card-title",
				children: "Viewport"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: { marginTop: 16 },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "check-row",
						children: ["Auto orbit", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: autoRotate,
							onChange: (event) => useStudio.setState({ autoRotate: event.target.checked })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "check-row",
						children: ["Grid", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: showGrid,
							onChange: (event) => useStudio.setState({ showGrid: event.target.checked })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "check-row",
						children: ["Gizmo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: showGizmo,
							onChange: (event) => useStudio.setState({ showGizmo: event.target.checked })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "check-row",
						children: ["Key light", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "range",
							min: 0,
							max: 3,
							step: .05,
							value: keyLight,
							onChange: (event) => useStudio.setState({
								keyLight: Number(event.target.value),
								mode: "lighting"
							})
						})]
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "dash-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "dash-card-title",
				children: "Material"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: { marginTop: 16 },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "check-row",
						children: ["Roughness", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "range",
							min: 0,
							max: 1,
							step: .01,
							value: roughness,
							onChange: (event) => useStudio.setState({
								roughness: Number(event.target.value),
								mode: "material"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "check-row",
						children: ["Metalness", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "range",
							min: 0,
							max: 1,
							step: .01,
							value: metalness,
							onChange: (event) => useStudio.setState({
								metalness: Number(event.target.value),
								mode: "material"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "check-row",
						children: ["Tint", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "color-input",
							type: "color",
							value: tint,
							onChange: (event) => useStudio.setState({
								tint: event.target.value,
								mode: "texture"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "settings-actions",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-btn",
								onClick: () => resetModel(),
								children: "New model"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-btn",
								onClick: () => clearSession(),
								children: "Clear session"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-btn",
								onClick: toggleFullscreen,
								children: "Fullscreen"
							})
						]
					})
				]
			})]
		})]
	});
}
function Landing({ leaving, onProceed }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bg-hero" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: leaving ? "container leaving" : "container enter",
		id: "landingContainer",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "logo-tag",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "sparkle",
					children: "+"
				}), "// Code at the Speed of Thoughts //"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "header-right",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "fullscreen-btn",
					id: "fullscreenBtn",
					title: "Toggle Fullscreen",
					onClick: toggleFullscreen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "[FS]" }), " Fullscreen"]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "main-content",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "title-section",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "brand-title",
							children: "Typeless"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "sub-title",
							children: "Code at the Speed of Thoughts"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "proceed-btn",
							id: "proceedBtn",
							onClick: onProceed,
							children: ["Proceed ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sparkle",
								children: ">>"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "info-card",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "info-text",
						children: "Futuristic sans-serif display interface featuring wide proportions, sharp geometric angles, and subtle diagonal cutouts."
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "Otf & Ttf" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "footer-center",
					children: "Multilingual Support"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "© 2026" })
			] })
		]
	})] });
}
function Home() {
	const entered = useStudio((s) => s.entered);
	const [leaving, setLeaving] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		loadSession();
		if (reduce) useStudio.setState({ autoRotate: false });
		let timer = 0;
		const unsub = useStudio.subscribe(() => {
			window.clearTimeout(timer);
			timer = window.setTimeout(() => saveSession(), 300);
		});
		return () => {
			unsub();
			window.clearTimeout(timer);
		};
	}, []);
	if (entered) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, { onLeave: () => {
		setLeaving(false);
		useStudio.setState({ entered: false });
	} });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landing, {
		leaving,
		onProceed: () => {
			if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
				useStudio.setState({ entered: true });
				return;
			}
			setLeaving(true);
			window.setTimeout(() => useStudio.setState({ entered: true }), 300);
		}
	});
}
//#endregion
export { Home as component };
