import { i as setResponseHeader, n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { r as extractScript, t as assertSafeScript } from "./compile-BfDkv7iY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/generate.functions-BFSeG3eT.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var SYSTEM = `You are an expert Three.js developer inside a code-CAD CNC tool.
Write JavaScript that builds a machined 3D part using the provided THREE object.
Rules:
- Output ONLY raw JavaScript. No markdown fences, no explanation.
- Do not import anything. THREE is already in scope as a parameter.
- End by returning a THREE.Object3D (Group or Mesh) with: return group;
- Use MeshStandardMaterial (metalness, roughness, color) so parts read as machined metal.
- Units are meters. Keep the part roughly inside a 3x3x3 box centered on the origin.
- Prefer CylinderGeometry, BoxGeometry, TorusGeometry, ConeGeometry, SphereGeometry, LatheGeometry, ExtrudeGeometry, Shape.
- If current model code is provided, modify that design to satisfy the request and return the FULL script.
- No network, DOM, window, document, loaders, or external assets.`;
function contentToString(content) {
	if (typeof content === "string") return content;
	if (Array.isArray(content)) return content.map((part) => {
		if (typeof part === "string") return part;
		if (part && typeof part === "object" && "text" in part) return String(part.text ?? "");
		return "";
	}).join("\n");
	return "";
}
var generateToolpath_createServerFn_handler = createServerRpc({
	id: "d49c3a3d8e5265e8b0a523551ac660da1bbc424bf80627ca37da95a9de7f1efc",
	name: "generateToolpath",
	filename: "src/lib/cad/generate.functions.ts"
}, (opts) => generateToolpath.__executeServer(opts));
var generateToolpath = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object") throw new Error("Missing prompt.");
	const prompt = "prompt" in input && typeof input.prompt === "string" ? input.prompt.trim() : "";
	const currentCode = "currentCode" in input && typeof input.currentCode === "string" ? input.currentCode : "";
	const tier = "tier" in input && input.tier === "advanced" ? "advanced" : "fast";
	if (prompt.length < 1 || prompt.length > 2e3) throw new Error("Prompt must be 1–2000 characters.");
	return {
		prompt,
		currentCode: currentCode.slice(0, 12e3),
		tier
	};
}).handler(generateToolpath_createServerFn_handler, async ({ data }) => {
	setResponseHeader("cache-control", "no-store");
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI generation is unavailable right now."
	};
	const user = data.currentCode ? `Current model code:\n${data.currentCode}\n\nRequested modification:\n${data.prompt}\n\nReturn the full updated script, not a diff.` : data.prompt;
	const call = () => fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		signal: AbortSignal.timeout(45e3),
		body: JSON.stringify({
			model: "grok-4.5",
			temperature: data.tier === "advanced" ? .4 : .2,
			max_tokens: data.tier === "advanced" ? 4096 : 2048,
			messages: [{
				role: "system",
				content: SYSTEM
			}, {
				role: "user",
				content: user
			}]
		})
	});
	try {
		let res = await call();
		if (res.status === 429 || res.status >= 500) {
			await new Promise((resolve) => setTimeout(resolve, 800));
			res = await call();
		}
		if (!res.ok) return {
			ok: false,
			error: `AI generation failed (${res.status}).`
		};
		const raw = contentToString((await res.json()).choices?.[0]?.message?.content);
		const code = extractScript(raw);
		if (!code) return {
			ok: false,
			error: "The model returned an empty toolpath."
		};
		assertSafeScript(code);
		return {
			ok: true,
			code
		};
	} catch (err) {
		return {
			ok: false,
			error: err instanceof Error ? err.message : "AI generation failed."
		};
	}
});
//#endregion
export { generateToolpath_createServerFn_handler };
