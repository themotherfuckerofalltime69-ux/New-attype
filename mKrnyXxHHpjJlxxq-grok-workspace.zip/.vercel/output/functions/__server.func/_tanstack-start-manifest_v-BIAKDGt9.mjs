//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BIAKDGt9.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Dn-3C8pJ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Dn-3C8pJ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BIcKPBBE.js"]
	}
} });
//#endregion
export { tsrStartManifest };
